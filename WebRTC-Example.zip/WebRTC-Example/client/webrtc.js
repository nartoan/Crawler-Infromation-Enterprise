var localVideo;
var remoteVideo;
var peerConnection;
var uuid;
var videoSelect;
var isNegotiating = false;

var peerConnectionConfig = {
  'iceServers': [
    { 'urls': 'stun:stun.services.mozilla.com' },
    { 'urls': 'stun:stun.l.google.com:19302' }
  ]
};

function pageReady() {
  uuid = uuid();

  localVideo = document.getElementById('localVideo');
  remoteVideo = document.getElementById('remoteVideo');
  videoSelect = document.querySelector("select#videoSource");

  serverConnection = io();
  serverConnection.on("message", gotMessageFromServer);
  videoSelect.onchange = getStream;

  navigator.mediaDevices.enumerateDevices().then(gotDevices).then(getStream).catch(errorHandler);
}

function getStream() {
  const constraints = {
    audio: true,
    video: {
      mandatory: { sourceId: videoSelect.value }
    }
  }

  if (navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
      localStream = stream;
      if (peerConnection) {
        peerConnection.removeStream(peerConnection.getLocalStreams()[0]);
        peerConnection.addStream(localStream);
      }
      
      localVideo.srcObject = localStream;
    }).catch(errorHandler);
  } else {
    alert('Your browser does not support getUserMedia API');
  }
}


function gotDevices(deviceInfos) {
  deviceInfos.forEach(deviceInfo => {
    const option = document.createElement("option");
    option.value = deviceInfo.deviceId;

    switch (deviceInfo.kind) {
      case "videoinput": {
        option.text = deviceInfo.label || `camera ${videoSelect.length + 1}`;
        videoSelect.appendChild(option);
        break;
      }
      default: {
        console.log(`Found another kind of device: ${deviceInfo}`);
      }
    }
  })
}

function start(isCaller) {
  peerConnection = new RTCPeerConnection(peerConnectionConfig);
  peerConnection.onicecandidate = gotIceCandidate;
  peerConnection.onaddstream = gotRemoteStream;
  peerConnection.onnegotiationneeded = function () {
    if (isNegotiating) {
      return;
    }
    isNegotiating = true;
    console.log("Trigger change camera");
    peerConnection.createOffer()
      .then(function (offer) {
        return peerConnection.setLocalDescription(offer);
      })
      .then(function () {
        console.log(peerConnection.localDescription)
        serverConnection.send(JSON.stringify({ 'sdp': peerConnection.localDescription, 'uuid': uuid }));
      }).catch(errorHandler);;
  };

  peerConnection.addStream(localStream);


  peerConnection.onsignalingstatechange = (e) => {
    isNegotiating = (peerConnection.signalingState != "stable");
  }


  if (isCaller) {
    peerConnection.createOffer().then(createdDescription).catch(errorHandler);
  }
}


function gotMessageFromServer(message) {
  
  if (!peerConnection) start(false);
  var signal = JSON.parse(message);

  // Ignore messages from ourself
  if (signal.uuid == uuid) return;

  if (signal.sdp) {
    peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp)).then(function () {
      console.log(peerConnection)
      // Only create answers in response to offers
      if (signal.sdp.type == 'offer') {
        console.log("create answer")
        peerConnection.createAnswer().then(createdDescription).catch(errorHandler);
      }
    }).catch(errorHandler);
  } else if (signal.ice) {
    peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice)).catch(errorHandler);
    console.log(peerConnection)
  } 
}

function gotIceCandidate(event) {
  console.log("ICE")
  if (event.candidate != null) {
    serverConnection.send(JSON.stringify({ 'ice': event.candidate, 'uuid': uuid }));
  }
}

function createdDescription(description) {
  console.log('got description');
  peerConnection.setLocalDescription(description).then(function () {
    serverConnection.send(JSON.stringify({ 'sdp': peerConnection.localDescription, 'uuid': uuid }));
  }).catch(errorHandler);
}

function gotRemoteStream(event) {
  console.log('got remote stream');
  remoteVideo.src = window.URL.createObjectURL(event.stream);
}

function errorHandler(error) {
  console.log(error);
}

function uuid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}
